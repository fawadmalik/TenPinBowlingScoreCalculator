package com.calculator.score;

public interface RulesEngine {
}
